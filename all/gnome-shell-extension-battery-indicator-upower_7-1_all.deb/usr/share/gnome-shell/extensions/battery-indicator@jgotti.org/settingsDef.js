var settingsDef = [
	{key: 'refresh-interval', type: 'uint', dflt: 300},
	{key: 'refresh-menuitem', type: 'boolean', dflt: true},
	{key: 'settings-menuitem', type: 'boolean', dflt: true},
	{key: 'symbolic-icons', type: 'boolean', dflt: true},
	{key: 'hidden-devices', type: 'strv', dflt: []}
]
