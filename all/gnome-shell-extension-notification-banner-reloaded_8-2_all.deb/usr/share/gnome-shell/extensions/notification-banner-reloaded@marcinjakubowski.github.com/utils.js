var PrefFields = {
    ANCHOR_VERTICAL        : 'anchor-vertical',
    ANCHOR_HORIZONTAL      : 'anchor-horizontal',
    PADDING_VERTICAL       : 'padding-vertical',
    PADDING_HORIZONTAL     : 'padding-horizontal',
    ANIMATION_TIME         : 'animation-time',
    ANIMATION_DIRECTION    : 'animation-direction',
    ALWAYS_MINIMIZE        : 'always-minimized',
};
